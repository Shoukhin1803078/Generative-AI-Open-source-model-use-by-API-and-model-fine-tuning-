from src.mcqgenerator.logger import logging

logging.info("hi, i am going to start my excution...")